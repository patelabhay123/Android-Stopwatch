# Android-Stopwatch
A simple Android stopwatch using JAVA (in Android Studio).

![HomePage](https://user-images.githubusercontent.com/109679563/180621359-f682f3d5-8290-4629-8185-a93597612cfa.png)

![Timer2Page](https://user-images.githubusercontent.com/109679563/180621363-55d852c9-c94d-4c01-b4b4-4ff4e380c8ca.png)

![TimerPage](https://user-images.githubusercontent.com/109679563/180621366-4c77a7b2-9f05-401c-ac01-1e959eb942df.png)
